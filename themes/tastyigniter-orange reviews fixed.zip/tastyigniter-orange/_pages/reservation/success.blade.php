---
title: main::lang.reservation.success.title
layout: default
permalink: /reservation/success/:hash?

'[booking]':
---
<div class="container">
    <div class="row py-4">
        <div class="col-6 m-auto">
            <div class="card">
                <div class="card-body">
                    @partial('booking::success')
                </div>
            </div>
        </div>
    </div>
</div>
