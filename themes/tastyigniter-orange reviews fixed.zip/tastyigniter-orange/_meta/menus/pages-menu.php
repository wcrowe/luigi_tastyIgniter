<?php
return [
    'name' => 'Pages menu',
    'items' => [
        [
            'title' => 'Pages',
            'code' => '',
            'type' => 'all-static-pages',
            'reference' => '',
        ],
    ],
];
