---
title: main::lang.contact.title
layout: default
permalink: /components

'[contact]':
---
<div class="container">
    <div class="row">
        <div class="col-md-6 m-auto">
            @component('contact')
        </div>
    </div>
</div>