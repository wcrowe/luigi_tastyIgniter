<div class="bottom-footer">
    <div class="container">
        <div class="row">
            <p class="small mb-0 p-3">
                {!! sprintf(
                    lang('main::lang.site_copyright'),
                    date('Y'),
                    setting('site_name'),
                    lang('system::lang.system_name')
                ).lang('system::lang.system_powered') !!}
            </p>
        </div>
    </div>
</div>