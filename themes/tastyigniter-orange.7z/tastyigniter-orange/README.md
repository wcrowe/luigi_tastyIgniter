Free Modern, Responsive and Clean TastyIgniter Theme based on Bootstrap 4.

### Required Extensions
- Igniter Cart
- Igniter FrontEnd
- Igniter Local
- Igniter Pages
- Igniter Pay Register
- Igniter Reservation
- Igniter User

### Features
- Responsive design
- Lightweight and very fast
- CSS3 animations
- Bootstrap support
- Google Maps integration

### Documentation
Full documentation for this theme can be found on here [Bootstrap 4](https://getbootstrap.com/docs)

#### To update all packages
Simply run $ npm install in the theme's root folder

### License
[The MIT License (MIT)](https://tastyigniter.com/licence/)